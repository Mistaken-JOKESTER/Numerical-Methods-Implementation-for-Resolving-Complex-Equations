double f_poly(double x);
double fdash_poly(double x);
double f_cos(double x);
double fdash_cos(double x);
double f_taninv(double x);
double fdash_taninv(double x);