#include <stdio.h>
#include <math.h>
#include "prob1.h"

int main(void)
{
	FILE *outputFile = fopen("convergence.txt", "w");
	if (outputFile == NULL) {
        perror("Error opening files");
        return 1;
    }

	double x0 = 0;
	printf("Initial guess: %16.9e, f(x0) = %16.9e\n", x0, f(x0));
	for (int i = 0; i < 20 && fabs(f(x0)) > 1e-12; i++) {
		double fval = f(x0);
		// print data to file for ploting
		fprintf(outputFile, "%f %f\n", x0, fval);

		double fdashval = fdash(x0);
		x0 = x0 - fval / fdashval;
		printf("%d: New x0 = %16.9e, f(x0) = %16.9e\n", i+1, x0, f(x0));
	}

	fprintf(outputFile, "%f %f\n", x0, f(x0));

	return 0;
}
