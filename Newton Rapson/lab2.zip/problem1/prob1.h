double fdash (double x);
double f (double x);