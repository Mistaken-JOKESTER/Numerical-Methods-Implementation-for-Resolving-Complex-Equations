#include <math.h>

/* cos(x) - 0.6*x = 0 */
/* f(x) = cos(x) - 0.6*x */
/* => f'(x) = -sin(x) - 0.6 */

double fdash(double x)
{
	return -1* sin(x) - 0.6;
}

double f(double x)
{
	return cos(x) - 0.6*x;
}